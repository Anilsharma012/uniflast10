import Shop from './Shop';

const NewArrivals = () => {
  return <Shop sortBy="newest" />;
};

export default NewArrivals;
